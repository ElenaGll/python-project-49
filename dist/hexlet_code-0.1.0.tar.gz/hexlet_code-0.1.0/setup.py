# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ElenaGll/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ElenaGll/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/ElenaGll/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/dd383086de587d05ebea/maintainability" /></a>\n\nHow to install:\npython3 -m pip install --user git+https://github.com/ElenaGll/python-project-49.git\n',
    'author': 'Elena Donyakina',
    'author_email': 'hellengoll@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
